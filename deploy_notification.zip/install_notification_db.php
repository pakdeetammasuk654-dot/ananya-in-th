<?php
// install_notification_db.php
// Script to create the notification_history table on the server environment.
// Upload this file to your server root and visit http://your-domain.com/install_notification_db.php

// 1. Load Configuration
if (file_exists('configs/config.php')) {
    require_once 'configs/config.php';
} else {
    die("Error: configs/config.php not found. Please make sure this file is in the root directory.");
}

// 2. Setup DB Connection
$dbConfig = $config['db'];
try {
    $pdo = new PDO(
        "mysql:host=" . $dbConfig['host'] . ";dbname=" . $dbConfig['dbname'],
        $dbConfig['user'],
        $dbConfig['pass']
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("set names utf8mb4");
    echo "✅ Database connection successful.<br>";
} catch (PDOException $e) {
    die("❌ Database connection failed: " . $e->getMessage());
}

// 3. Define SQL
$sql = "CREATE TABLE IF NOT EXISTS notification_history (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    body TEXT,
    type VARCHAR(50) DEFAULT NULL,
    url VARCHAR(500) DEFAULT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

// 4. Execute SQL
try {
    $pdo->exec($sql);
    echo "✅ Table 'notification_history' created successfully (or already exists).<br>";
    echo "<hr>";
    echo "Status: <strong>READY</strong>";
} catch (PDOException $e) {
    echo "❌ Error creating table: " . $e->getMessage();
}
?>