<?php
echo "Date: " . date('Y-m-d H:i:s');
echo "<br>Timezone: " . date_default_timezone_get();
