<?php
namespace App\Managers\Telephone\Util;
class AppMessage{
    public $xmessage;

    public function __construct($xmessage)
    {
        $this->xmessage = $xmessage;
    }
}

