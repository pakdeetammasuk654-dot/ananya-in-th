<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Bag Colors</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <?php include 'web_menu.php'; ?>
    <div class="container mt-5 pt-5">
        <h2>Bag Colors Management</h2>
        <div class="alert alert-info">Feature under development.</div>
        <a href="/web/dashboard" class="btn btn-secondary">Back to Dashboard</a>
    </div>
</body>

</html>