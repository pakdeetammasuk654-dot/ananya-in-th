<?php
// DB Credentials
$host = "localhost";
$user = "zoqlszwh_ananyadb";
$pass = "IntelliP24.X";
$dbname = "zoqlszwh_ananyadb";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 1. Drop UNIQUE Index on user_buddha_assign if it exists
    try {
        // Check if index exists
        $stmt = $pdo->prepare("SHOW INDEX FROM user_buddha_assign WHERE Key_name = 'memberid'");
        $stmt->execute();
        if ($stmt->fetch()) {
            $pdo->exec("ALTER TABLE user_buddha_assign DROP INDEX memberid");
            echo "Dropped UNIQUE index on memberid from user_buddha_assign\n";
        } else {
            // Sometimes it might be unique_user_buddha
            $stmt = $pdo->prepare("SHOW INDEX FROM user_buddha_assign WHERE Key_name = 'unique_user_buddha'");
            $stmt->execute();
            if ($stmt->fetch()) {
                $pdo->exec("ALTER TABLE user_buddha_assign DROP INDEX unique_user_buddha");
                echo "Dropped UNIQUE index unique_user_buddha from user_buddha_assign\n";
            }
        }
    } catch (Exception $e) {
        echo "Note on Buddha: " . $e->getMessage() . "\n";
    }

    // 2. Drop UNIQUE Index on user_temple_assign if it exists
    try {
        $stmt = $pdo->prepare("SHOW INDEX FROM user_temple_assign WHERE Key_name = 'unique_user_temple'");
        $stmt->execute();
        if ($stmt->fetch()) {
            $pdo->exec("ALTER TABLE user_temple_assign DROP INDEX unique_user_temple");
            echo "Dropped UNIQUE index unique_user_temple from user_temple_assign\n";
        } else {
            // Check memberid index if named differently
            $stmt = $pdo->prepare("SHOW INDEX FROM user_temple_assign WHERE Key_name = 'memberid'");
            $stmt->execute();
            if ($stmt->fetch()) {
                $pdo->exec("ALTER TABLE user_temple_assign DROP INDEX memberid");
                echo "Dropped UNIQUE index memberid from user_temple_assign\n";
            }
        }
    } catch (Exception $e) {
        echo "Note on Temple: " . $e->getMessage() . "\n";
    }

    // 3. Ensure tables have AUTO_INCREMENT ID if they don't already (create_buddha_table implies yes, but let's be sure columns exist)

    // Add columns if missing (just in case) or modify structure. 
    // Usually existing structure is fine if we just dropped the Unique Key.

    echo "Schema migration for multiple items completed.\n";

} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>