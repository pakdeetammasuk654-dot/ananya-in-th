<?php
define('PREFIX', 'prefix');
define('PATH', 'https://www.ananya.in.th/');
define('BASE_DIR', __DIR__ . '/..');
define('UPLOAD_DIR', BASE_DIR . '/public/uploads');
define('PHOTO_DIR', BASE_DIR . '/public/photo');

