<?php
chdir(dirname(__DIR__));
require 'index.php';
