<?php
$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;
$config['db']['host'] = "localhost";
$config['db']['user'] = "zoqlszwh_ananyadb";
$config['db']['pass'] = "IntelliP24.X";
$config['db']['dbname'] = "zoqlszwh_ananyadb";

return $config;