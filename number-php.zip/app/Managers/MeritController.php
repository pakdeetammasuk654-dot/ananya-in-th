<?php

namespace App\Managers;

use PDO;

class MeritController extends Manager
{
    public function view($request, $response)
    {
        $id = $request->getQueryParams()['id'] ?? null;

        $item = null;

        if ($id) {
            if ($id >= 1 && $id <= 8) {
                // Fetch from Buddha Pang
                $stmt = $this->db->prepare("SELECT * FROM buddha_pang_tb WHERE buddha_day = :day");
                // Mapping ID to Day: 1=Sun, 2=Mon... 8=Wed Night?
                // Wait, typically ID matches day or row ID.
                // In MeritAssignPickerAct: 
                // 1=Sun, 2=Mon, 3=Tue, 4=Wed, 5=Thu, 6=Fri, 7=Sat, 8=WedNight
                // In buddha_pang_tb, usually buddha_day 1=Sun, ... 8=Wed Night.
                // Let's assume ID maps safely to buddha_day for 1-8.
                $stmt->execute(['day' => $id]);
                $pang = $stmt->fetch(PDO::FETCH_OBJ);

                if ($pang) {
                    $item = [
                        'title' => $pang->pang_name,
                        'image' => $pang->image_url,
                        'content' => $pang->description
                    ];
                }
            } elseif ($id == 9) {
                $item = [
                    'title' => 'วิธีการปรับดวงเรื่องความรักเงินงาน',
                    'image' => '/uploads/buddha/default.png', // Placeholder
                    'content' => 'แนะนำให้ทำบุญถวายสังฆทาน ตักบาตรพระสงฆ์ 9 รูป หรือปล่อยปลา เพื่อเสริมดวงชะตาด้านความรักและการเงินให้ดียิ่งขึ้น'
                ];
            } elseif ($id == 10) {
                $item = [
                    'title' => 'การทำบุญช่วยส่งเสริมชะตาอาภัพคู่',
                    'image' => '/uploads/buddha/default.png', // Placeholder
                    'content' => 'แนะนำให้ถวายของคู่ เช่น เทียนคู่ แจกันคู่ หมอนคู่ หรือทำบุญสมทบทุนงานแต่งงาน เพื่อแก้เคล็ดเสริมดวงคู่ครอง'
                ];
            }
        }

        if (!$item) {
            $item = [
                'title' => 'ไม่พบข้อมูล',
                'image' => '',
                'content' => 'ไม่พบข้อมูลสำหรับรายการที่ระบุ'
            ];
        }

        return $this->container->get('view')->render($response, 'web_merit_view.php', [
            'item' => (object) $item
        ]);
    }
}
