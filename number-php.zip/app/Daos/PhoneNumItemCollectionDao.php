<?php
namespace App\Daos;

class PhoneNumItemCollectionDao{
    public $phonenumTop4 = array();
    public $phonenumberSell = array();



}